# GhostLink Solo — single-board BLE wardriving for WarBLE Go

Stock GhostESP's GhostLink bridge is a **two-board rig**: a BLE "core" that talks
to the phone, wired over UART to a radio "peer" that does the scanning. A single
board can't serve the phone *and* scan, so the bridge forwards every phone command
over the wire and answers `comm link down` when no peer is attached — which is why
one board + iPhone sits at **0 APs**.

This patch adds a **solo mode**: when no peer has been paired, the bridge runs the
command on its own chip and streams the output straight back over BLE. One ESP32 +
iPhone, instant pairless BLE connect, Wi-Fi APs flowing into WarBLE Go. No app
protocol change — the phone already speaks this exact GATT service.

## Why it works on one radio

The thing that made the single-board **Wi-Fi-AP** approach impossible — `wdstream`
tears down the SoftAP to scan — is *harmless here*, because the phone link is **BLE**,
not Wi-Fi. The Wi-Fi radio is free to scan while the (unused) SoftAP is down. BLE +
Wi-Fi run concurrently through ESP-IDF's coexistence arbiter; the firmware already
proves this path with `wdstream -wifi -ble` dual-radio mode.

## Files changed (base: GhostESP-Revival `main` @ `e96d708`)

| File | Change |
|---|---|
| `include/managers/ble_bridge_manager.h` | Declares `ble_bridge_feed_local_output()` |
| `main/managers/ble_bridge_manager.c` | Solo dispatch (local exec when unpaired), the feed impl, stop-stream-on-disconnect |
| `main/core/glog.c` | Mirror command output to the phone in solo mode |
| `main/core/commands/cmd_wdstream.c` | Stream `WD:…` lines to the phone in solo mode |

Two-board core/peer behaviour is **untouched**: every new path is gated on
`last_peer` being empty (a paired rig always has it set) and compiles to a no-op on
non-BLE targets (ESP32-S2).

## Apply + build

```sh
cd <your GhostESP-Revival checkout>           # must be on main @ e96d708 (or rebase the patch)
git apply /path/to/ghostlink-solo-single-board-ble.patch
# or, to keep authorship: git am < ...   (this is a plain diff, so git apply is simplest)

idf.py set-target esp32c5       # or esp32c6 / esp32s3 — your board
idf.py build flash monitor
```

Any BLE-capable GhostESP target works (C3/C5/C6/S3/ESP32). S2 has no native BLE and
is unaffected (solo compiles out).

## Use it

1. Flash **one** board. **Do not run `blebridge pair`** — pairing is what tells the
   firmware you have a second radio. An unpaired board is a solo board.
2. `blebridge start` (or let the saved-enabled state auto-start it). It advertises
   **"GhostESP Bridge"** over BLE.
3. In **WarBLE Go**, enable the Wi-Fi bridge. The app connects (no pairing prompt),
   sends `wdstream start -wifi`, and `WD:AP` records stream into the HUD and the
   wardrive CSV. The activity console shows the live device log.
4. Disconnecting the phone stops the scan automatically.

To go back to a two-board rig later, `blebridge pair <peer_name>` as usual — that
repopulates `last_peer` and solo mode switches itself off.

## The one thing to watch on hardware

Solo runs a BLE GATT connection and a continuous Wi-Fi channel-hopping scan on the
same 2.4 GHz radio. ESP-IDF coexistence handles this, and AP records are tiny and
infrequent, so BLE should only see extra latency. If BLE drops during scans on your
board, raise the scan interval to give the radio more idle time between bursts:

```
wdstream start -wifi -i 3000        # 3 s between channel scans instead of the 2 s default
```

(WarBLE Go sends the 2 s default; the interval can be tuned in `GhostLink.swift`'s
`startCommand` if needed.) This has not yet been validated on hardware — it's a
careful source-level change against Revival `main`, not a flashed-and-tested build.
