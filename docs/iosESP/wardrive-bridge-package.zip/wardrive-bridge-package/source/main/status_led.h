// status_led.h — tiny status indicator for the WarBLE wardrive bridge.
//
// Three states map to what the board is doing, so you can read it at a glance
// with no serial monitor:
//   IDLE         off            (powered, Bluetooth not up yet)
//   ADVERTISING  slow blink     (waiting for the phone)
//   STREAMING    solid          (phone connected, APs flowing)
//
// The LED kind and GPIO are chosen in menuconfig (see main/Kconfig.projbuild):
// an addressable WS2812/NeoPixel (default), a plain on/off GPIO LED, or none.

#pragma once

typedef enum {
    STATUS_LED_IDLE = 0,
    STATUS_LED_ADVERTISING,
    STATUS_LED_STREAMING,
} status_led_state_t;

void status_led_init(void);
void status_led_set(status_led_state_t state);
